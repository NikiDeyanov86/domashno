#include <stdio.h>

using namespace std;

int copy1(char* a, char* b) {
    for(int i = 0; i < 6; i++) {
        a[i] = b[i];
    }
    }
int print_ar(char* p) {
    for(int i = 0; p[i] != '\0'; i++) {
        printf("%c", p[i]);
    }
    }

int main()
{
    char a[6];
    char b[6] = "hello";
    copy1(a, b);
    print_ar(a);
}
