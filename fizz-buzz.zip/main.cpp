#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
    int d3,d5,br = 0;
    for(int i = 1; i<= 20; i++) {
        br = 0;
        d3 = i%3;
        d5 = i%5;
        d3 || br++;
        d3 || br++;
        d5 || br++;
        switch(br) {
            case 1: printf("buzz\n"); break;
            case 2: printf("fizz\n"); break;
            case 3: printf("fizz-buzz\n"); break;
            default: printf("%d\n", i); break;
            }
    }
}
