#include <iostream>
#include <stdio.h>

using namespace std;

double square_root(double S, int n) {
    double x0 = 57367357457,x;
    for(int i = 1;i <= n;i++) {
        x = (x0 + S/x0 ) / 2;
        x0 = x;
     }
    S = x0;
     return S;
    }

int main()
{
    printf("%f" , square_root(9 , 50));
    return 0;
}
