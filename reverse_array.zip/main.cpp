#include <stdio.h>

using namespace std;

int myreverse(int* ar, int size1)
{
    int i,n;
    int vr[5];
    for(i = 0; i < size1; i++) {
        vr[i] = ar[i];
    }
    for(i = size1 - 1, n = 0; i >= 0; i--, n++)
    {
        ar[n] = *(vr + i);
    }
}
int print_array(int* ar, int size1)
{
    int i;
    for(i = 0; i < size1; i++) {
        printf("ar[%d] = %d\n", i , *(ar + i));
    }
}

int main()
{
    int ar[5] = {1,2,7,15,4};
    int q = sizeof(ar) / 4;
    myreverse(ar, q);
    print_array(ar, q);
}
