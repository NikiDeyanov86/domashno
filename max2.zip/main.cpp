#include <stdio.h>

using namespace std;

int max2(int* ar, int size1) {
    int high = ar[0];
    int high2 = ar[0];
    int i;
    for( i = 0; i < size1; i++) {

        if(ar[i] > high) {
                high = ar[i];
        }
    }
    for(i = 0; i < size1; i++) {
        if(ar[i] > high2 && ar[i] < high) high2 = ar[i];
    }
    return high2;
    }

int main()
{
    int ar[5] = {200,2070,2072,6000,5};
    printf("the second highest is %d", max2(ar, sizeof(ar)/ 4));
    return 0;
}
